<?php
declare(strict_types=1);

header('Location: index.php?view=admin');
exit;
